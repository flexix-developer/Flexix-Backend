window.onload = function () {
    fetch("http://ceproject.thddns.net:3323/token/getbestsellerbook"
    , {
        method: "GET", // สามารถเปลี่ยนเป็น 'POST', 'PUT', ถ้ามีความจำเป็น
        headers: {'Authorization':'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDc3MzQyNzUsInVzZXJJZCI6MX0.vZCgeTAFCwyRsvRRy-cL7zTxUxokucy9gtLHAviwEkI'},
      })
      .then((response) => response.json())
      .then((data) => {
        const APIData =  data.product
        const sourceElement = document.getElementById("row-7");
        const container = sourceElement.parentNode;
        container.innerHTML = ""; // Clear the container to prepare for new elements
        APIData.forEach((item, i) => {
          const clonedElement = sourceElement.cloneNode(true);
          clonedElement.id = `${sourceElement.id}`; // No need to escape backticks here
          // Customize the clonedElement as necessary
          clonedElement.querySelectorAll("*").forEach((child, index) => {
            
            const newId = `${child.id}`; // No need to escape backticks here
            child.id = newId; // Set the new id
            // Check and change src for images
          
// // Check and change src for image-3
    if (child.tagName === "IMG" && child.id.includes("image-3")) {
    child.src = item.Product_Image; // Set the new src
  }          
// // Check and change src for button-1
                   if (child.id.includes("button-1")) {
                    child.addEventListener("click", function () {
                      window.location.href = `detail.html?id=${item.ID}`;
                      console.log(item.ID);
                    });
                  }          
// Modify text for Bookname
  if (child.id.includes("Bookname")) {
    child.textContent = item.Product_Name; // Set the new text
  }          
// // Check and change src for button-1
                   if (child.id.includes("button-1")) {
                    child.addEventListener("click", function () {
                      window.location.href = `detail.html?id=${item.ID}`;
                      console.log(item.ID);
                    });
                  }          
// Modify text for BookPrice
  if (child.id.includes("BookPrice")) {
    child.textContent = item.Product_Price; // Set the new text
  }          
// // Check and change src for button-1
                   if (child.id.includes("button-1")) {
                    child.addEventListener("click", function () {
                      window.location.href = `detail.html?id=${item.ID}`;
                      console.log(item.ID);
                    });
                  }
        
// // Check and change src for button-1
    if (child.tagName === "BUTTON" && child.id.includes("button-1")) {
    child.value = item.ID; // Set the new src
    child.dataset.id = item.ID;
    }          
// // Check and change src for button-1
                   if (child.id.includes("button-1")) {
                    child.addEventListener("click", function () {
                      window.location.href = `detail.html?id=${item.ID}`;
                      console.log(item.ID);
                    });
                  }


            
          });
          container.appendChild(clonedElement); // Add the clonedElement to the container
        });
      })
      .catch((error) => console.error("Error:", error));
  };